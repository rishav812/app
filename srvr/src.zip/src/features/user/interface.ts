export interface IAddProduct{
    productname:string,
    price:number,
    description:string,
    image:string,
    category_id:string
}

export interface IAddCategory{
    category_name:string
}